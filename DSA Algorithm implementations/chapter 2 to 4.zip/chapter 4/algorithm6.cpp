#include<bits/stdc++.h>
using namespace std;
int  binarySearch(int arr[],int n,int item ){
    int low=0;
    int high=n-1;
    int mid=int(low+high)/2;
   
    while (low<=high){
        mid=int(low+high)/2;
        if(item==arr[mid]){
            return (mid+1);
            break;
        }
        if(item<arr[mid]){
            high=mid-1;
        }
        else
       low=mid+1;
        

        
    }
    return -1;
   
}
int main(){
    int arr[]={1,2,3,9,20,30};
    int item=9;
    int n=sizeof(arr)/sizeof(arr[0]);
    cout<<binarySearch(arr,n,item);
}